"""
INC Racing — backend API (FastAPI + SQLite)

Эндпоинты:
  POST /api/game-score   — принять результат игры от клиента
  GET  /api/leaderboard  — топ-100 игроков
  GET  /api/health       — проверка живости сервиса

Анти-чит (базовый уровень для MVP):
  1. Валидация Telegram initData по HMAC-подписи (доказывает, что запрос
     реально пришёл из Telegram, а не был подделан вручную с произвольным
     telegram_id). Включается переменной окружения BOT_TOKEN.
  2. Проверка правдоподобия очков: score должен соответствовать формуле
     score = distance + coins*10 (клиентская формула), с небольшим допуском.
  3. Ограничение по частоте отправки результатов на одного пользователя
     (защита от спама/накрутки скриптом).
  4. Ограничение по абсолютным величинам (разумные верхние пределы).

Это не "непробиваемая" защита (полноценно её можно сделать только серверной
симуляцией физики), но она закрывает самые простые способы подделать счёт
через devtools/curl.
"""

import os
import hashlib
import hmac
import time
from urllib.parse import parse_qsl

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

import database

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")  # токен бота из @BotFather, для проверки initData
MIN_SUBMIT_INTERVAL_SEC = 4        # минимальный интервал между отправками для одного игрока
MAX_PLAUSIBLE_DISTANCE = 200_000   # метров — разумный потолок за один забег
MAX_PLAUSIBLE_COINS = 5_000
SCORE_FORMULA_TOLERANCE = 5        # допуск на округления

app = FastAPI(title="INC Racing API")

app.mount("/game", StaticFiles(directory="game"), name="game")


@app.get("/")
def home():
    return FileResponse("game/index.html")

# Для MVP разрешаем все origin (Telegram WebApp открывается в своём webview).
# В проде стоит сузить allow_origins до домена вашего фронтенда, если нужно.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    database.init_db()


# ------------------------------------------------------------------------
# Схемы запросов/ответов
# ------------------------------------------------------------------------
class GameScoreIn(BaseModel):
    telegram_id: str = Field(..., min_length=1, max_length=64)
    username: str | None = Field(default=None, max_length=64)
    score: int = Field(..., ge=0)
    distance: int = Field(..., ge=0)
    coins: int = Field(..., ge=0)
    init_data: str | None = Field(default=None, description="Telegram.WebApp.initData")


class GameScoreOut(BaseModel):
    ok: bool
    verified: bool
    is_new_record: bool
    best_score: int


class LeaderboardEntry(BaseModel):
    telegram_id: str
    username: str | None
    score: int
    distance: int
    coins: int


class LeaderboardOut(BaseModel):
    players: list[LeaderboardEntry]


# ------------------------------------------------------------------------
# Telegram initData validation (см. https://core.telegram.org/bots/webapps#validating-data-received-via-the-web-app)
# ------------------------------------------------------------------------
def validate_telegram_init_data(init_data: str, bot_token: str) -> bool:
    if not init_data or not bot_token:
        return False
    try:
        pairs = dict(parse_qsl(init_data, strict_parsing=True))
    except ValueError:
        return False

    received_hash = pairs.pop("hash", None)
    if not received_hash:
        return False

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    return hmac.compare_digest(calculated_hash, received_hash)


# ------------------------------------------------------------------------
# Anti-cheat sanity checks
# ------------------------------------------------------------------------
def score_is_plausible(score: int, distance: int, coins: int) -> bool:
    if distance > MAX_PLAUSIBLE_DISTANCE or coins > MAX_PLAUSIBLE_COINS:
        return False
    expected = distance + coins * 10
    return abs(score - expected) <= SCORE_FORMULA_TOLERANCE


# ------------------------------------------------------------------------
# Routes
# ------------------------------------------------------------------------
@app.get("/api/health")
def health():
    return {"status": "ok", "time": time.time()}


@app.post("/api/game-score", response_model=GameScoreOut)
def submit_game_score(payload: GameScoreIn):
    # 1) базовая правдоподобность очков
    if not score_is_plausible(payload.score, payload.distance, payload.coins):
        raise HTTPException(status_code=400, detail="Score does not match expected formula")

    # 2) rate limiting — не чаще одного результата раз в N секунд на игрока
    last_ts = database.get_last_submission_time(payload.telegram_id)
    if last_ts is not None and (time.time() - last_ts) < MIN_SUBMIT_INTERVAL_SEC:
        raise HTTPException(status_code=429, detail="Too many submissions, slow down")

    # 3) проверка подлинности Telegram initData (если BOT_TOKEN настроен на сервере)
    verified = False
    if BOT_TOKEN:
        verified = validate_telegram_init_data(payload.init_data or "", BOT_TOKEN)
        if not verified:
            # Не блокируем полностью (гость может играть из обычного браузера),
            # но помечаем результат как неподтверждённый — его можно исключать
            # из публичной таблицы лидеров при желании.
            pass

    database.log_submission(
        payload.telegram_id, payload.username, payload.score,
        payload.distance, payload.coins, verified,
    )
    is_new_record = database.upsert_best_score(
        payload.telegram_id, payload.username, payload.score,
        payload.distance, payload.coins,
    )

    best = database.get_best_score(payload.telegram_id)
    return GameScoreOut(
        ok=True,
        verified=verified,
        is_new_record=is_new_record,
        best_score=best["score"] if best else payload.score,
    )


@app.get("/api/leaderboard", response_model=LeaderboardOut)
def leaderboard(limit: int = 100):
    limit = max(1, min(limit, 100))
    players = database.get_top_players(limit)
    return LeaderboardOut(players=players)


@app.get("/api/best-score/{telegram_id}")
def best_score(telegram_id: str):
    row = database.get_best_score(telegram_id)
    if not row:
        return {"telegram_id": telegram_id, "score": 0, "distance": 0, "coins": 0}
    return row
