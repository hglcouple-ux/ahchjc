"""
INC Racing — слой доступа к базе данных (SQLite).

Хранит:
- best_scores: лучший результат каждого игрока (для таблицы лидеров)
- score_log:   журнал всех отправленных результатов (для анти-чит анализа /аудита)
"""

import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).parent / "inc_racing.db"


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS best_scores (
                telegram_id TEXT PRIMARY KEY,
                username    TEXT,
                score       INTEGER NOT NULL,
                distance    INTEGER NOT NULL,
                coins       INTEGER NOT NULL,
                updated_at  REAL NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS score_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id TEXT NOT NULL,
                username    TEXT,
                score       INTEGER NOT NULL,
                distance    INTEGER NOT NULL,
                coins       INTEGER NOT NULL,
                verified    INTEGER NOT NULL DEFAULT 0,
                created_at  REAL NOT NULL
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_score_log_tid ON score_log(telegram_id)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_best_scores_score ON best_scores(score DESC)"
        )


def log_submission(telegram_id: str, username: str, score: int, distance: int, coins: int, verified: bool):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO score_log (telegram_id, username, score, distance, coins, verified, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (telegram_id, username, score, distance, coins, int(verified), time.time()),
        )


def upsert_best_score(telegram_id: str, username: str, score: int, distance: int, coins: int) -> bool:
    """Update the player's best score if this run beats their previous best.
    Returns True if a new record was set."""
    with get_conn() as conn:
        row = conn.execute(
            "SELECT score FROM best_scores WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        if row is None or score > row["score"]:
            conn.execute(
                """INSERT INTO best_scores (telegram_id, username, score, distance, coins, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(telegram_id) DO UPDATE SET
                     username=excluded.username,
                     score=excluded.score,
                     distance=excluded.distance,
                     coins=excluded.coins,
                     updated_at=excluded.updated_at""",
                (telegram_id, username, score, distance, coins, time.time()),
            )
            return True
        return False


def get_best_score(telegram_id: str):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM best_scores WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return dict(row) if row else None


def get_top_players(limit: int = 100):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT telegram_id, username, score, distance, coins FROM best_scores "
            "ORDER BY score DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def get_last_submission_time(telegram_id: str):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT created_at FROM score_log WHERE telegram_id = ? ORDER BY created_at DESC LIMIT 1",
            (telegram_id,),
        ).fetchone()
        return row["created_at"] if row else None
